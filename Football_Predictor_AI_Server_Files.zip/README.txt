# Football Predictor AI

## Render Web Service configuration
- Runtime: Node
- Build Command: `npm install`
- Start Command: `npm start`
- Root Directory: leave blank
- Environment Variable: `API_FOOTBALL_KEY` = your private API-Football key

Do not commit the API key to GitHub. Add it only in Render > Environment > Environment Variables.

This version fetches today's fixtures from API-Football. It does not generate betting predictions or guarantee accuracy.
